from .shape import Shape
from .circle import Circle
from .triangle import Triangle
from .square import Square
from .rectangle import Rectangle
import turtle