def calculate(a, b, c):
    return b * (a - c)


print(calculate(3, 2, 1))
