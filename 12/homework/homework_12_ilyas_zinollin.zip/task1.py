yoda = ['on Python', 'programming ', 'I like ']

print(yoda[2] + yoda[1] + yoda[0])

# Доп. задание

yoda.reverse()

print(''.join(yoda))
