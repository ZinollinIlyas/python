multiplier = 5

for i in range(1, 10):
    print(f"{multiplier} * {i} = {multiplier * i}")
